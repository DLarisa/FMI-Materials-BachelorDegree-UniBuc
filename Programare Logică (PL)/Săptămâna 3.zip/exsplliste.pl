lung([],0).
lung([_|T],N) :- lung(T,K), N is K+1.

concat([],L,L).
concat([H|T],L,[H|M]) :- concat(T,L,M).

aparitii(_,[],0).
aparitii(X,[X|T],N) :- aparitii(X,T,K), N is K+1.
aparitii(X,[H|T],N) :- X=\=H, aparitii(X,T,N).

