%Sortarea prin insertie directa:

inssort([],[]).
inssort([H|T],L) :- inssort(T,M),insert(H,M,L).

insert(H,[],[H]).
insert(H,[X|L],[H,X|L]) :- H=<X.
insert(H,[X|L],[X|C]) :- H>X,insert(H,L,C).

%Bubblesort-ul:

parcurge([],[],true).
parcurge([X],[X],true).
parcurge([X,Y|T],[X|C],B) :- X=<Y,parcurge([Y|T],C,B).
parcurge([X,Y|T],[Y|C],false) :- X>Y,parcurge([X|T],C,_).

bsort(L,S) :- parcurge(L,S,true) ; (parcurge(L,M,false),bsort(M,S)).

%Putem afisa lista obtinuta dupa fiecare parcurgere, astfel:

bblsort(L,S) :- write(L),nl,((parcurge(L,S,true),write(S),nl) ; (parcurge(L,M,false),write(M),nl,bblsort(M,S))).

%Sortarea prin interclasare:

sparge([],[],[]).
sparge([A],[A],[]).
sparge([A,B|T],[A|U],[B|V]) :- sparge(T,U,V).

merge([],L,L).
merge(L,[],L).
merge([A|T],[B|U],[A|L]) :- A=<B,merge(T,[B|U],L).
merge([A|T],[B|U],[B|L]) :- A>B,merge([A|T],U,L).

mergesort([],[]).
mergesort([X],[X]).
mergesort([A,B|T],S) :- sparge([A,B|T],M,N),mergesort(M,Q),mergesort(N,R),merge(Q,R,S).

/*Daca nu cerem decat un rezultat, merge si urmatoarea sortare prin interclasare,
care, insa, pentru fiecare satisfacere a lui concat([X|M],[Y|N],[A,B|T]),
intoarce acelasi rezultat, deci da lista sortata de atatea ori cate posibilitati
are pentru satisfacerea lui concat([X|M],[Y|N],[A,B|T]) la toti pasii sortarii.*/

concat([],L,L).
concat([H|T],M,[H|L]) :- concat(T,M,L).

msort([],[]).
msort([X],[X]).
msort([A,B|T],S) :- concat([X|M],[Y|N],[A,B|T]),msort([X|M],Q),msort([Y|N],R),merge(Q,R,S).

%Am folosit, pentru interclasare, predicatul merge de mai sus.

/*Quicksort-ul, folosind concatenarea de mai sus:
La fiecare iteratie, pivotul va fi capul listei care se sorteaza la pasul respectiv:*/

taie(_,[],[],[]).
taie(P,[H|T],[H|L],M) :- H=<P,taie(P,T,L,M).
taie(P,[H|T],L,[H|M]) :- H>P,taie(P,T,L,M).

qsort([],[]).
qsort([P|T],S) :- taie(P,T,M,N),qsort(M,Q),qsort(N,R),concat(Q,[P|R],S).

% inmultirea cu 2 sau 3 a elementelor unei liste:

mult2([],[]).
mult2([H|T],[K|V]) :- K is 2*H,mult2(T,V).

mult3([],[]).
mult3([H|T],[K|V]) :- K is 3*H,mult3(T,V).

% lista numerelor de forma 2^k*3^n, cu k,n naturale, k<=K, n<=N:

puteri23(0,0,[1]).
puteri23(K,0,L) :- K>0,PK is K-1,puteri23(PK,0,T),mult2(T,V),concat(T,V,L).
puteri23(0,M,L) :- M>0,PM is M-1,puteri23(0,PM,T),mult3(T,V),concat(T,V,L).
puteri23(K,M,L) :- K>0,M>0,PK is K-1,PM is M-1,puteri23(PK,PM,T),mult2(T,V),mult3(V,W),mult2(W,Z),concat(T,V,Y),concat(W,Z,X),concat(Y,X,L).

elimdup([],[]).
elimdup([H|T],[H|L]) :- stergetot(H,T,M),elimdup(M,L).

stergetot(_,[],[]).
stergetot(X,[X|T],L) :- stergetot(X,T,L).
stergetot(X,[H|T],[H|L]) :- H\=X,stergetot(X,T,L).

% dati interogarile:
% puteri23(2,2,L),elimdup(L,M),write(M).
% puteri23(5,7,L),elimdup(L,M),write(M),write('***'),qsort(M,S),write(S).

