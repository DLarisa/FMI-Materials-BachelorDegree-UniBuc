a.
b.
c :- a,not(b).
d :- a,c.
e :- c;d.
f :- c;not(c),not(a).

/*
In SWISH SWI-Prolog-ul online:
?- trace,c.
?- trace,d.
?- trace,e.
?- trace,f.
In SWI-Prolog-ul instalat local, merge si:
?- trace.
?- c.
?- d.
?- e.
?- f.
?- notrace.
*/

/*
Observati ca , e mai prioritara decat ;
asa ca am putut scrie fara paranteze la f.
*/
